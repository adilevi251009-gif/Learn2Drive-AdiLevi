﻿
using Model;
using System;
using System.Collections.Generic;
using System.Data.OleDb;
using System.Linq;

namespace ViewModel
{
    public class StatusDB : BaseDB
    {
        public StatusList SelectAll()
        {
            string sql = "SELECT * FROM Status";
            return new StatusList(base.Select(sql));
        }

        protected override BaseEntity CreateModel(BaseEntity entity, OleDbDataReader reader)
        {
            Status s = entity as Status;
            if (s != null)
            {
                base.CreateModel(entity, reader);
                s.StatusName = reader["StatusName"] != DBNull.Value ? reader["StatusName"].ToString() : string.Empty;
            }
            return s;
        }

        public override BaseEntity NewEntity()
        {
            return new Status();
        }

        public static Status SelectById(int id)
        {
            StatusDB db = new StatusDB();
            StatusList list = db.SelectAll();
            return list.Find(item => item.Id == id);
        }

        protected override void CreateDeletedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Status s = entity as Status;
            if (s != null)
            {
                cmd.CommandText = "DELETE FROM Status WHERE Id=@id";
                cmd.Parameters.Add(new OleDbParameter("@id", s.Id));
            }
        }

        protected override void CreateInsertdSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Status s = entity as Status;
            if (s != null)
            {
                cmd.CommandText = "INSERT INTO Status (StatusName) VALUES (@statusName)";
                cmd.Parameters.Add(new OleDbParameter("@statusName", s.StatusName));
            }
        }

        protected override void CreateUpdatedSQL(BaseEntity entity, OleDbCommand cmd)
        {
            Status s = entity as Status;
            if (s != null)
            {
                cmd.CommandText = "UPDATE Status SET StatusName=@statusName WHERE Id=@id";
                cmd.Parameters.Add(new OleDbParameter("@statusName", s.StatusName));
                cmd.Parameters.Add(new OleDbParameter("@id", s.Id));
            }
        }
    }
}
//using Model;
//using System;
//using System.Collections.Generic;
//using System.Data.OleDb;
//using System.Linq;
//using System.Text;
//using System.Threading.Tasks;

//namespace ViewModel
//{
//    public class StatusDB:BaseDB
//    {
//        public StatusList SelectAll()
//        {
//            command.CommandText = $"SELECT * FROM Status";
//            StatusList statusList = new StatusList(base.Select());
//            return statusList;
//        }

//        protected override BaseEntity CreateModel(BaseEntity entity)
//        {
//            Status s = entity as Status;
//            s.StatusName = reader["StatusName"].ToString();
//            base.CreateModel(entity);
//            return s;
//        }

//        public override BaseEntity NewEntity()
//        {
//            return new Status();
//        }

//        static private StatusList list = new StatusList();

//        public static Status SelectById(int id)
//        {
//            StatusDB db = new StatusDB();
//            list = db.SelectAll();

//            Status s = list.Find(item => item.Id == id);
//            return s;
//        }

//        protected override void CreateDeletedSQL(BaseEntity entity, OleDbCommand cmd)
//        {
//            Status s = entity as Status;

//            if (s != null)
//            {

//                string sqlStr = $"DELETE FROM Status WHERE Id=@id"; 

//                command.CommandText = sqlStr;
//                command.Parameters.Add(new OleDbParameter("@id", s.Id));
//            }
//        }

//        protected override void CreateInsertdSQL(BaseEntity entity, OleDbCommand cmd)
//        {
//            Status s = entity as Status;

//            if (s != null)
//            {
//                string sqlStr = $"INSERT INTO Status (StatusName) VALUES (@statusName)";

//                command.CommandText = sqlStr;
//                command.Parameters.Add(new OleDbParameter("@statusName", s.StatusName));
//            }
//        }

//        protected override void CreateUpdatedSQL(BaseEntity entity, OleDbCommand cmd)
//        {
//            Status s = entity as Status;

//            if (s != null)
//            {

//                string sqlStr = $"UPDATE Status SET StatusName=@statusName WHERE Id=@id"; 

//                command.CommandText = sqlStr;
//                command.Parameters.Add(new OleDbParameter("@statusName", s.StatusName));
//                command.Parameters.Add(new OleDbParameter("@id", s.Id));
//            }
//        }
//    }
//}